'use strict';
/*
 * HealthRev LAN server
 * - Serves clinic-app.html to every device on the local network
 * - Stores all data in data/clinic-db.json (with a daily backup in data/backups)
 * - Verifies logins itself, so nothing is served without signing in
 * No external packages: only Node.js built-ins.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');

const PORT = Number(process.env.PORT) || 3000;
const ROOT = __dirname;
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'clinic-db.json');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
const APP_FILE = path.join(ROOT, 'clinic-app.html');
const KEEP_BACKUPS = 30;

const ARR = ['clinics', 'doctors', 'patients', 'appointments', 'invoices', 'receipts', 'expenses', 'records', 'payouts'];
const KIND = { p: 'patients', a: 'appointments', i: 'invoices', c: 'clinics', d: 'doctors', r: 'receipts', e: 'expenses', m: 'records', y: 'payouts', u: 'users' };
const PREFIX = { patients: 'P', appointments: 'A', invoices: 'INV', clinics: 'C', doctors: 'D', receipts: 'REC', expenses: 'EXP', records: 'MR', payouts: 'PAY', users: 'U' };
const ALL_PERMS = ['dashboard', 'clinics', 'doctors', 'patients', 'appointments', 'billing', 'cashbox', 'expenses', 'medical', 'accounts', 'fees', 'reports'];
const KEY_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const SESSION_IDLE_MS = 60 * 60 * 1000;

/* ---------------------------------------------------------------- database */
function emptyState() {
  return { clinics: [], doctors: [], patients: [], appointments: [], invoices: [], receipts: [], expenses: [], records: [], payouts: [],
    closings: {}, users: [], recovery: null, seq: {}, migrated: {} };
}
let db = { version: 1, state: emptyState() };

function pad(n) { return String(n).padStart(4, '0'); }
function today() {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}
function fixSeq() {
  for (const [k, coll] of Object.entries(KIND)) {
    let max = 0;
    (db.state[coll] || []).forEach(r => {
      const m = String(r && r.id).match(/(\d+)$/);
      if (m) max = Math.max(max, Number(m[1]));
    });
    db.state.seq[k] = Math.max(Number(db.state.seq[k]) || 1, max + 1);
  }
}
function load() {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  if (fs.existsSync(DB_FILE)) {
    try {
      const j = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
      db = { version: Number(j.version) || 1, state: Object.assign(emptyState(), j.state) };
    } catch (e) {
      console.error('ERROR: could not read ' + DB_FILE + ' (' + e.message + ').');
      console.error('Restore the latest file from ' + BACKUP_DIR + ' and try again.');
      process.exit(1);
    }
  }
  fixSeq();
}
function dailyBackup() {
  try {
    const f = path.join(BACKUP_DIR, 'clinic-db-' + today() + '.json');
    if (!fs.existsSync(f)) {
      fs.copyFileSync(DB_FILE, f);
      const files = fs.readdirSync(BACKUP_DIR).filter(x => /^clinic-db-\d{4}-\d{2}-\d{2}\.json$/.test(x)).sort();
      files.slice(0, Math.max(0, files.length - KEEP_BACKUPS)).forEach(x => fs.unlinkSync(path.join(BACKUP_DIR, x)));
    }
  } catch (e) { console.error('Backup warning:', e.message); }
}
function save() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DB_FILE);
  dailyBackup();
}
function nextId(kind) {
  const n = db.state.seq[kind]++;
  return PREFIX[KIND[kind]] + '-' + pad(n);
}

/* ---------------------------------------------------------------- security */
function randHex(n) { return crypto.randomBytes(n).toString('hex'); }
function hashPw(pw, salt) { return crypto.pbkdf2Sync(String(pw), String(salt), 100000, 32, 'sha256').toString('hex'); }
function safeEq(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
function genKey() {
  const b = crypto.randomBytes(16);
  const s = Array.from(b).map(x => KEY_CHARS[x % KEY_CHARS.length]).join('');
  return s.match(/.{4}/g).join('-');
}
const normKey = k => String(k || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
function makeRecovery() {
  const key = genKey(), salt = randHex(16);
  return { key, rec: { salt, hash: hashPw(normKey(key), salt), createdAt: today() } };
}

// Sessions survive a server restart (e.g. a power cut), so staff are not logged out and unsaved edits are not lost.
// Only a SHA-256 of each token is stored on disk, never the token itself.
const SESS_FILE = path.join(DATA_DIR, 'sessions.json');
const sha = t => crypto.createHash('sha256').update(String(t)).digest('hex');
const sessions = new Map();           // sha256(token) -> { userId, last }
function loadSessions() {
  try {
    const j = JSON.parse(fs.readFileSync(SESS_FILE, 'utf8'));
    Object.keys(j).forEach(k => sessions.set(k, { userId: j[k], last: Date.now() }));
  } catch (e) { /* no sessions yet */ }
}
function saveSessions() {
  try {
    const o = {};
    sessions.forEach((v, k) => { o[k] = v.userId; });
    fs.writeFileSync(SESS_FILE, JSON.stringify(o));
  } catch (e) { console.error('Session save warning:', e.message); }
}
function newSession(userId) {
  const t = randHex(24);
  sessions.set(sha(t), { userId, last: Date.now() });
  saveSessions();
  return t;
}
function dropSessions(userId) {
  for (const [k, s] of sessions) if (s.userId === userId) sessions.delete(k);
  saveSessions();
}
function authUser(req) {
  const t = req.headers['x-token'];
  const k = t && sha(t);
  const s = k && sessions.get(k);
  if (!s) return null;
  if (Date.now() - s.last > SESSION_IDLE_MS) { sessions.delete(k); saveSessions(); return null; }
  const u = db.state.users.find(x => x.id === s.userId);
  if (!u || u.active === false) { sessions.delete(k); saveSessions(); return null; }
  s.last = Date.now();
  return u;
}

const fails = new Map();
function blockedFor(key) {
  const f = fails.get(key);
  return f && f.until && Date.now() < f.until ? Math.ceil((f.until - Date.now()) / 1000) : 0;
}
function addFail(key, limit, ms) {
  const f = fails.get(key) || { n: 0, until: 0 };
  f.n++;
  if (f.n >= limit) { f.until = Date.now() + ms; f.n = 0; }
  fails.set(key, f);
}

let setupPin = null;
function refreshSetupPin() {
  setupPin = db.state.users.length === 0 ? (process.env.SETUP_PIN || String(crypto.randomInt(100000, 1000000))) : null;
}

/* ---------------------------------------------------------------- helpers */
const publicUser = u => ({ id: u.id, name: u.name, username: u.username, role: u.role, perms: u.perms, doctorId: u.doctorId || '', active: u.active !== false, createdAt: u.createdAt });
const hasPerm = (u, k) => !!u && (u.role === 'admin' || (u.perms || []).includes(k));
function publicState() {
  const s = db.state;
  return Object.assign({}, s, {
    users: s.users.map(publicUser),
    recovery: s.recovery ? { createdAt: s.recovery.createdAt } : null
  });
}
// Medical records are only ever sent to accounts that have the "medical" permission.
function publicStateFor(u) {
  const st = publicState();
  if (!hasPerm(u, 'medical')) st.records = [];
  // doctors' fee payouts: visible to whoever handles fees or the cash drawer (cash paid out changes the drawer), writable only with "fees"
  if (!hasPerm(u, 'fees') && !hasPerm(u, 'cashbox')) st.payouts = [];
  return st;
}
function json(res, code, obj) {
  const b = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(b);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', c => {
      size += c.length;
      if (size > 25 * 1024 * 1024) { reject(new Error('too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch (e) { reject(new Error('bad json')); }
    });
    req.on('error', reject);
  });
}
const validUsername = s => /^[a-z0-9._-]{3,}$/.test(s);

const STATIC = {
  '/': ['clinic-app.html', 'text/html; charset=utf-8'],
  '/index.html': ['clinic-app.html', 'text/html; charset=utf-8'],
  '/clinic-app.html': ['clinic-app.html', 'text/html; charset=utf-8'],
  '/favicon.ico': ['healthrev-icon.ico', 'image/x-icon'],
  '/healthrev-icon.ico': ['healthrev-icon.ico', 'image/x-icon'],
  '/healthrev-icon-512.png': ['healthrev-icon-512.png', 'image/png'],
  '/chart.umd.min.js': ['chart.umd.min.js', 'application/javascript; charset=utf-8'],
  '/xlsx.full.min.js': ['xlsx.full.min.js', 'application/javascript; charset=utf-8']
};
function serveStatic(p, res) {
  const e = STATIC[p];
  if (!e) { res.writeHead(404); return res.end('Not found'); }
  const f = path.join(ROOT, e[0]);
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end('Missing file: ' + e[0]); }
  res.writeHead(200, { 'Content-Type': e[1], 'Cache-Control': 'no-cache' });
  fs.createReadStream(f).pipe(res);
}

/* ---------------------------------------------------------------- API */
async function handle(req, res) {
  const url = new URL(req.url, 'http://local');
  const p = url.pathname;
  if (!p.startsWith('/api/')) {
    if (req.method !== 'GET') { res.writeHead(405); return res.end(); }
    return serveStatic(p, res);
  }
  const ip = req.socket.remoteAddress || '';
  let body = {};
  if (req.method === 'POST') {
    try { body = await readBody(req); } catch (e) { return json(res, 400, { error: 'طلب غير صالح' }); }
  }
  const need = () => {
    const u = authUser(req);
    if (!u) json(res, 401, { error: 'انتهت الجلسة أو لم يتم تسجيل الدخول' });
    return u;
  };
  const needAdmin = () => {
    const u = need();
    if (!u) return null;
    if (u.role !== 'admin') { json(res, 403, { error: 'هذه العملية للمدير فقط' }); return null; }
    return u;
  };
  const s = db.state;

  if (p === '/api/status' && req.method === 'GET') {
    return json(res, 200, { server: true, needsSetup: s.users.length === 0, version: db.version });
  }

  /* ---- first run: create the admin ---- */
  if (p === '/api/setup' && req.method === 'POST') {
    if (s.users.length) return json(res, 403, { error: 'تم إعداد النظام من قبل' });
    const key = 'setup|' + ip, wait = blockedFor(key);
    if (wait) return json(res, 429, { error: 'محاولات كثيرة خاطئة. انتظر ' + wait + ' ثانية.' });
    if (!setupPin || !safeEq(String(body.pin || '').trim(), setupPin)) {
      addFail(key, 5, 60000);
      return json(res, 403, { error: 'رمز الإعداد غير صحيح. هو الرقم الظاهر في نافذة الخادم.' });
    }
    const name = String(body.name || '').trim(), username = String(body.username || '').trim().toLowerCase(), password = String(body.password || '');
    if (!name) return json(res, 400, { error: 'أدخل الاسم' });
    if (!validUsername(username)) return json(res, 400, { error: 'اسم المستخدم 3 أحرف على الأقل (إنجليزي وأرقام بدون مسافات)' });
    if (password.length < 6) return json(res, 400, { error: 'كلمة المرور 6 أحرف على الأقل' });
    const seed = body.state || {};
    ARR.forEach(c => { if (Array.isArray(seed[c])) s[c] = seed[c].filter(r => r && typeof r.id === 'string'); });
    fixSeq();
    const salt = randHex(16);
    const user = { id: nextId('u'), name, username, role: 'admin', perms: ALL_PERMS.slice(), active: true, salt, hash: hashPw(password, salt), createdAt: today() };
    s.users.push(user);
    const r = makeRecovery();
    s.recovery = r.rec;
    db.version++; save(); setupPin = null;
    return json(res, 200, { token: newSession(user.id), user: publicUser(user), recoveryKey: r.key });
  }

  /* ---- login / logout ---- */
  if (p === '/api/login' && req.method === 'POST') {
    const username = String(body.username || '').trim().toLowerCase();
    const key = 'login|' + ip + '|' + username, wait = blockedFor(key);
    if (wait) return json(res, 429, { error: 'محاولات كثيرة خاطئة. انتظر ' + wait + ' ثانية.' });
    const u = s.users.find(x => x.username === username);
    const ok = !!u && u.active !== false && safeEq(hashPw(String(body.password || ''), u.salt), u.hash);
    if (!ok) { addFail(key, 5, 30000); return json(res, 401, { error: 'اسم المستخدم أو كلمة المرور غير صحيحة' }); }
    fails.delete(key);
    return json(res, 200, { token: newSession(u.id), user: publicUser(u) });
  }
  if (p === '/api/logout' && req.method === 'POST') {
    const t = req.headers['x-token'];
    if (t && sessions.delete(sha(t))) saveSessions();
    return json(res, 200, { ok: true });
  }

  /* ---- password recovery with the recovery key (no login needed) ---- */
  if (p === '/api/recover' && req.method === 'POST') {
    const key = 'recover|' + ip, wait = blockedFor(key);
    if (wait) return json(res, 429, { error: 'محاولات كثيرة خاطئة. انتظر ' + wait + ' ثانية.' });
    const username = String(body.username || '').trim().toLowerCase(), password = String(body.password || '');
    if (password.length < 6) return json(res, 400, { error: 'كلمة المرور الجديدة 6 أحرف على الأقل' });
    const u = s.users.find(x => x.username === username && x.role === 'admin');
    const ok = !!u && !!s.recovery && safeEq(hashPw(normKey(body.key), s.recovery.salt), s.recovery.hash);
    if (!ok) { addFail(key, 5, 60000); return json(res, 403, { error: 'بيانات الاسترجاع غير صحيحة (اسم المستخدم أو المفتاح، أو الحساب ليس مدير)' }); }
    fails.delete(key);
    u.salt = randHex(16); u.hash = hashPw(password, u.salt); u.active = true;
    dropSessions(u.id);
    const r = makeRecovery();
    s.recovery = r.rec;
    db.version++; save();
    return json(res, 200, { key: r.key });
  }

  /* ---- everything below needs a valid session ---- */
  if (p === '/api/state' && req.method === 'GET') {
    const me = need(); if (!me) return;
    return json(res, 200, { version: db.version, state: publicStateFor(me) });
  }
  if (p === '/api/changes' && req.method === 'GET') {
    const me = need(); if (!me) return;
    const since = Number(url.searchParams.get('since'));
    if (since === db.version) return json(res, 200, { changed: false, version: db.version });
    return json(res, 200, { changed: true, version: db.version, state: publicStateFor(me) });
  }
  if (p === '/api/id' && req.method === 'POST') {
    if (!need()) return;
    if (!KIND[body.kind] || body.kind === 'u') return json(res, 400, { error: 'نوع غير معروف' });
    const id = nextId(body.kind);
    save();
    return json(res, 200, { id });
  }
  if (p === '/api/ids' && req.method === 'POST') {
    if (!need()) return;
    const n = Math.floor(Number(body.n));
    if (!KIND[body.kind] || body.kind === 'u') return json(res, 400, { error: 'نوع غير معروف' });
    if (!(n >= 1 && n <= 5000)) return json(res, 400, { error: 'العدد يجب أن يكون بين 1 و 5000' });
    const ids = [];
    for (let i = 0; i < n; i++) ids.push(nextId(body.kind));
    save();
    return json(res, 200, { ids });
  }
  if (p === '/api/sync' && req.method === 'POST') {
    const me = need(); if (!me) return;
    const ops = Array.isArray(body.ops) ? body.ops : [];
    // medical records: writing needs the "medical" permission, deleting is for the admin only
    for (const op of ops) {
      if (op && op.c === 'payouts') {
        if (!hasPerm(me, 'fees')) return json(res, 403, { error: 'ليس لديك صلاحية أتعاب الأطباء' });
        if (op.t === 'd' && me.role !== 'admin') return json(res, 403, { error: 'حذف عمليات صرف الأتعاب للمدير فقط' });
      }
      if (op && op.c === 'records') {
        if (!hasPerm(me, 'medical')) return json(res, 403, { error: 'ليس لديك صلاحية السجل الطبي' });
        if (op.t === 'd' && me.role !== 'admin') return json(res, 403, { error: 'حذف السجل الطبي للمدير فقط' });
      }
    }
    const prev = db.version;
    let changed = false;
    for (const op of ops) {
      if (!op || typeof op.c !== 'string') continue;
      if (op.c === 'closings') {
        const k = String(op.id);
        if (op.t === 'u' && op.r && typeof op.r === 'object') { s.closings[k] = op.r; changed = true; }
        else if (op.t === 'd' && k in s.closings) { delete s.closings[k]; changed = true; }
        continue;
      }
      if (!ARR.includes(op.c)) continue;
      const arr = s[op.c];
      const i = arr.findIndex(r => r.id === op.id);
      if (op.t === 'u') {
        if (!op.r || typeof op.r !== 'object' || String(op.r.id) !== String(op.id)) continue;
        if (i >= 0) arr[i] = op.r; else arr.push(op.r);
        changed = true;
      } else if (op.t === 'd' && i >= 0) { arr.splice(i, 1); changed = true; }
    }
    if (changed) { db.version++; save(); }
    return json(res, 200, { version: db.version, prev });
  }
  if (p === '/api/change-password' && req.method === 'POST') {
    const u = need(); if (!u) return;
    if (!safeEq(hashPw(String(body.old || ''), u.salt), u.hash)) return json(res, 400, { error: 'كلمة المرور الحالية غير صحيحة' });
    const np = String(body.new || '');
    if (np.length < 6) return json(res, 400, { error: 'كلمة المرور الجديدة 6 أحرف على الأقل' });
    u.salt = randHex(16); u.hash = hashPw(np, u.salt);
    save();
    return json(res, 200, { ok: true });
  }

  /* ---- admin only ---- */
  if (p === '/api/users' && req.method === 'POST') {
    const me = needAdmin(); if (!me) return;
    const id = body.id ? String(body.id) : '';
    const existing = id ? s.users.find(x => x.id === id) : null;
    if (id && !existing) return json(res, 404, { error: 'المستخدم غير موجود' });
    const name = String(body.name || '').trim(), username = String(body.username || '').trim().toLowerCase();
    const password = String(body.password || ''), role = body.role === 'admin' ? 'admin' : 'user', active = body.active !== false;
    if (!name) return json(res, 400, { error: 'أدخل الاسم' });
    if (!validUsername(username)) return json(res, 400, { error: 'اسم المستخدم 3 أحرف على الأقل (إنجليزي وأرقام بدون مسافات)' });
    if (s.users.some(x => x.username === username && x.id !== id)) return json(res, 400, { error: 'اسم المستخدم مستخدم بالفعل' });
    if ((!id || password) && password.length < 6) return json(res, 400, { error: 'كلمة المرور 6 أحرف على الأقل' });
    if (existing && existing.id === me.id && (role !== 'admin' || !active)) return json(res, 400, { error: 'لا يمكنك تغيير دورك أو إيقاف حسابك' });
    const others = s.users.filter(x => x.id !== id);
    if (others.concat([{ role, active }]).filter(x => x.role === 'admin' && x.active !== false).length < 1) return json(res, 400, { error: 'يجب أن يبقى مدير واحد مفعّل على الأقل' });
    const perms = role === 'admin' ? ALL_PERMS.slice() : (Array.isArray(body.perms) ? body.perms.filter(x => ALL_PERMS.includes(x)) : []);
    let salt = existing ? existing.salt : '', hash = existing ? existing.hash : '';
    if (password) { salt = randHex(16); hash = hashPw(password, salt); }
    const doctorId = String(body.doctorId || '');
    const user = { id: id || nextId('u'), name, username, role, perms, doctorId, active, salt, hash, createdAt: existing ? existing.createdAt : today() };
    if (existing) s.users[s.users.indexOf(existing)] = user; else s.users.push(user);
    if (!active || password) dropSessions(user.id);
    db.version++; save();
    return json(res, 200, { user: publicUser(user) });
  }
  if (p === '/api/users/delete' && req.method === 'POST') {
    const me = needAdmin(); if (!me) return;
    const u = s.users.find(x => x.id === String(body.id));
    if (!u) return json(res, 404, { error: 'المستخدم غير موجود' });
    if (u.id === me.id) return json(res, 400, { error: 'لا يمكنك حذف حسابك الحالي' });
    if (u.role === 'admin' && s.users.filter(x => x.id !== u.id && x.role === 'admin' && x.active !== false).length < 1) return json(res, 400, { error: 'لا يمكن حذف آخر مدير' });
    s.users = s.users.filter(x => x.id !== u.id);
    dropSessions(u.id);
    db.version++; save();
    return json(res, 200, { ok: true });
  }
  if (p === '/api/recovery-key' && req.method === 'POST') {
    const me = needAdmin(); if (!me) return;
    if (!safeEq(hashPw(String(body.password || ''), me.salt), me.hash)) return json(res, 400, { error: 'كلمة المرور غير صحيحة' });
    const r = makeRecovery();
    s.recovery = r.rec;
    db.version++; save();
    return json(res, 200, { key: r.key });
  }
  if (p === '/api/import' && req.method === 'POST') {
    const me = needAdmin(); if (!me) return;
    const d = body.data;
    if (!d || typeof d !== 'object') return json(res, 400, { error: 'ملف النسخة الاحتياطية غير صالح' });
    for (const c of ARR) {
      if (d[c] !== undefined && !(Array.isArray(d[c]) && d[c].every(r => r && typeof r.id === 'string'))) return json(res, 400, { error: 'بيانات "' + c + '" غير صالحة في الملف' });
    }
    ARR.forEach(c => { s[c] = Array.isArray(d[c]) ? d[c] : []; });
    s.closings = d.closings && typeof d.closings === 'object' ? d.closings : {};
    if (d.seq && typeof d.seq === 'object') Object.keys(KIND).forEach(k => { if (k !== 'u') s.seq[k] = Math.max(Number(s.seq[k]) || 1, Number(d.seq[k]) || 1); });
    fixSeq();
    db.version++; save();
    return json(res, 200, { ok: true });
  }

  return json(res, 404, { error: 'غير موجود' });
}

/* ---------------------------------------------------------------- start */
function lanUrls() {
  const out = [];
  Object.values(os.networkInterfaces()).forEach(list => (list || []).forEach(i => {
    if (i.family === 'IPv4' && !i.internal) out.push('http://' + i.address + ':' + PORT);
  }));
  return out;
}

load();
const args = process.argv.slice(2);
if (args[0] === '--reset-users') {
  db.state.users = []; db.state.recovery = null; db.version++; save();
  fs.rmSync(SESS_FILE, { force: true });
  console.log('All user accounts were removed. Patients, invoices, cashbox and expenses are untouched.');
  console.log('Start the server again and create a new admin account.');
  process.exit(0);
}
if (args[0] === '--set-password') {
  const [, uname, pw] = args;
  const u = db.state.users.find(x => x.username === String(uname || '').toLowerCase());
  if (!u || !pw || pw.length < 6) {
    console.log('Usage: node server.js --set-password <username> <new-password-6+chars>');
    console.log(u ? '' : 'User not found. Existing users: ' + db.state.users.map(x => x.username).join(', '));
    process.exit(1);
  }
  u.salt = randHex(16); u.hash = hashPw(pw, u.salt); u.active = true; db.version++; save();
  fs.rmSync(SESS_FILE, { force: true });
  console.log('Password changed for ' + u.username + '. Everyone must sign in again.');
  process.exit(0);
}

loadSessions();
refreshSetupPin();
const server = http.createServer((req, res) => {
  handle(req, res).catch(e => { console.error(e); if (!res.headersSent) json(res, 500, { error: 'خطأ في الخادم' }); });
});
server.on('error', e => {
  console.error(e.code === 'EADDRINUSE' ? 'ERROR: port ' + PORT + ' is already in use. Close the other server window or set a different PORT.' : e.message);
  process.exit(1);
});
server.listen(PORT, '0.0.0.0', () => {
  console.log('==============================================');
  console.log(' HealthRev server is running');
  console.log('==============================================');
  console.log(' On THIS computer : http://localhost:' + PORT);
  const urls = lanUrls();
  console.log(' From other devices (same network):');
  (urls.length ? urls : ['(no network connection detected)']).forEach(u => console.log('     ' + u));
  console.log(' Data folder      : ' + DATA_DIR);
  if (setupPin) {
    console.log('');
    console.log(' FIRST RUN - setup PIN (type it on the setup screen): ' + setupPin);
  }
  console.log('');
  console.log(' Keep this window open. Close it to stop the server.');
  console.log('==============================================');
});
