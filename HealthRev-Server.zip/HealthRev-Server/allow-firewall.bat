@echo off
net session >nul 2>&1
if errorlevel 1 (
  echo.
  echo Right-click this file and choose "Run as administrator".
  echo.
  pause
  exit /b 1
)
netsh advfirewall firewall add rule name="HealthRev Server" dir=in action=allow protocol=TCP localport=3000 profile=private,domain
echo.
echo Done. Other devices on the same network can now reach the server on port 3000.
echo.
pause
